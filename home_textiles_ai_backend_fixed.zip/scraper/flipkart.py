def scrape_flipkart(product: str):
    return [
        {
            "product": f"{product} - Flipkart Combo Pack",
            "price": "₹230",
            "link": "https://www.flipkart.com/item/example",
            "website": "Flipkart"
        }
    ]
